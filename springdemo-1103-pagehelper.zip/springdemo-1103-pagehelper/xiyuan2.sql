/*
Navicat MySQL Data Transfer

Source Server         : 阿里云服务器
Source Server Version : 50642
Source Host           : 47.94.101.75:3306
Source Database       : xiyuan2

Target Server Type    : MYSQL
Target Server Version : 50642
File Encoding         : 65001

Date: 2020-10-28 18:22:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for SYS_DICT
-- ----------------------------
DROP TABLE IF EXISTS `SYS_DICT`;
CREATE TABLE `SYS_DICT` (
  `code` varchar(36) NOT NULL COMMENT '主键',
  `type_code` varchar(36) DEFAULT NULL COMMENT '类型code',
  `name` varchar(50) DEFAULT NULL COMMENT '展示值',
  `value` int(20) DEFAULT NULL COMMENT '使用值',
  `fixed` int(2) DEFAULT NULL COMMENT 'default 0不固定，固定的话用1',
  `creater` varchar(20) DEFAULT NULL COMMENT '新建人',
  `create_time` datetime DEFAULT NULL COMMENT '新建时间',
  `updater` varchar(20) DEFAULT NULL COMMENT '编辑人',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间',
  PRIMARY KEY (`code`),
  KEY `sys_type` (`type_code`),
  CONSTRAINT `sys_type` FOREIGN KEY (`type_code`) REFERENCES `SYS_DICT_TYPE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of SYS_DICT
-- ----------------------------
INSERT INTO `SYS_DICT` VALUES ('182d4db6-aa50-11ea-aa1b-00163e08c9ed', '9ed92c7e-aa4f-11ea-aa1b-00163e08c9ed', '男', '0', '1', null, null, null, null);
INSERT INTO `SYS_DICT` VALUES ('222cf983-aa50-11ea-aa1b-00163e08c9ed', '9ed92c7e-aa4f-11ea-aa1b-00163e08c9ed', '女', '1', '1', null, null, null, null);
INSERT INTO `SYS_DICT` VALUES ('41dd8b92-ab28-11ea-aa1b-00163e08c9ed', 'f4b60ac1-ab27-11ea-aa1b-00163e08c9ed', '普通用户', '0', '1', null, null, null, null);
INSERT INTO `SYS_DICT` VALUES ('5629e5ba-ab28-11ea-aa1b-00163e08c9ed', 'f4b60ac1-ab27-11ea-aa1b-00163e08c9ed', '管理员用户', '1', '1', null, null, null, null);

-- ----------------------------
-- Table structure for SYS_DICT_TYPE
-- ----------------------------
DROP TABLE IF EXISTS `SYS_DICT_TYPE`;
CREATE TABLE `SYS_DICT_TYPE` (
  `code` varchar(36) NOT NULL,
  `name` varchar(50) DEFAULT NULL COMMENT '用于展示',
  `value` varchar(50) DEFAULT NULL COMMENT '用于前段(建立唯一索引)',
  `creater` varchar(20) DEFAULT NULL COMMENT '新建人',
  `create_time` datetime DEFAULT NULL COMMENT '新建时间',
  `updater` varchar(20) DEFAULT NULL COMMENT '编辑人',
  `updater_time` datetime DEFAULT NULL COMMENT '编辑时间',
  PRIMARY KEY (`code`),
  UNIQUE KEY `key_value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of SYS_DICT_TYPE
-- ----------------------------
INSERT INTO `SYS_DICT_TYPE` VALUES ('9ed92c7e-aa4f-11ea-aa1b-00163e08c9ed', '性别', 'sex', null, null, null, null);
INSERT INTO `SYS_DICT_TYPE` VALUES ('f4b60ac1-ab27-11ea-aa1b-00163e08c9ed', '用户类型', 'userType', null, null, null, null);

-- ----------------------------
-- Table structure for tb_commodity
-- ----------------------------
DROP TABLE IF EXISTS `tb_commodity`;
CREATE TABLE `tb_commodity` (
  `id` varchar(36) DEFAULT NULL COMMENT '主键',
  `commodity_type` int(11) DEFAULT NULL COMMENT '商品类型',
  `commodity_name` varchar(150) DEFAULT NULL COMMENT '商品名称',
  `commodity_price` decimal(10,0) DEFAULT NULL COMMENT '商品价格',
  `commodity_all_num` int(11) DEFAULT NULL COMMENT '商品总数',
  `commodity_sold_num` int(11) DEFAULT NULL COMMENT '商品已售数量',
  `remark` varchar(2000) DEFAULT NULL COMMENT '备忘',
  `creater` varchar(255) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updater` varchar(255) DEFAULT NULL COMMENT '编辑人',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_commodity
-- ----------------------------
INSERT INTO `tb_commodity` VALUES ('ff4f5e964c136e2d8da766d8a121b797', null, '测试商品一', null, '1000', null, null, null, null, null, null);
INSERT INTO `tb_commodity` VALUES ('ef1cee300aa5de2ae26658ce73f798c5', null, '测试商品一', null, '1000', null, null, null, null, null, null);
INSERT INTO `tb_commodity` VALUES ('43486796d2871dfbec0f62951750ea4c', null, '测试商品一', null, '1000', null, null, null, null, null, null);

-- ----------------------------
-- Table structure for tb_order
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order` (
  `id` varchar(36) DEFAULT NULL COMMENT '主键',
  `user_id` varchar(36) DEFAULT NULL COMMENT '用户编号',
  `product_id` varchar(255) DEFAULT NULL COMMENT '产品编号',
  `order_price` decimal(10,0) DEFAULT NULL COMMENT '订单成交价格',
  `creater` varchar(255) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updater` varchar(255) DEFAULT NULL COMMENT '编辑人',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES ('7691a6412f6500446c7058f2f61af415', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('0b20d9c155a4cdec7b4c26735a7df705', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('09a21d697cfde5d837817f5906780b8a', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('50e91017d0d8a7ffbcc4ba65539176f8', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('1b6a6cf77fa8d8609a3d86a856912187', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('78da7064c6824d0ae65b9eafe9ba0172', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('0a4e5514f321aaa6c75a74408236e66d', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('6ba201881a5bc2719fb6600785ad6471', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('5255e299ce26b01be57c97d723731fc4', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('3e7ca8e2d905423e36a7da95838ac7ad', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('93fae81ea28f8097990447f7e0d3d111', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('874f0780dab823129eb9a5264bd01397', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('1cdc4adb621b4ca68d9730177154bae0', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('e67abf0eda905121d180093ca0c572b4', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('94fc60b8855d5a1f4affb3c98303c90e', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('4244800d93c1fa2a3d13240206701836', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('1d9974ff582a8add1a51bad745feea5e', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('a889b1626f11e939618ab80158bbaf25', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('bd35a17741444b408a683d7cbdbc419e', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('183ebb9e9979ec0e0547c4cad70c4262', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('8d296f318d159b17ea9e121782ee06b9', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('85b246cba8eba2e4d19c09c26ac28d92', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('84a5149ef5369e091d6604021c0974ec', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('f16d84c325a1d2d4d8abc82c2808d7a6', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('6e27a7fdba4750d53182f1e969bf4c0b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('cf1aad9681127166603a7a54cc7fd4f2', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('bed4b215e7ca1bc64ba2e65f4d604fa1', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('351fcd6f4396d560417c01c64578c29d', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('66d9d55fb5adb7e3ca0f0051eed9e4fe', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('d44bfa7bf5aa312400e0bfa27eee2721', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('73fed8eadacf55f80801b7a62c3bc2bd', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('37d5e3caa58a365c0422f1da2aadbbbd', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('14f532847c27fe37ccacb44786ec78f0', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('d26d73fb11147762f9b48d2a15c6e70d', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('86ff81eaf521aa933d35618d02b88cc2', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('2d9fe637c95f27215945c1ec84da2b0b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('9f8b77b99983ad7e5145a86cec6c2a6b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('8a91abefb49c2518688c89bcec2fca31', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('79d8e90d65686967aec842d34671df01', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('b159d0268a6529df2a792804d1b087c6', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('dc3e9e361ee88dda8ef4480f6e917e64', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('69fc1f61526de22cfd29f6689bd834d9', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('295e67658acb23c60274af128f784155', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('c9edfe444d426eeec9851ad65f8c4212', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('e0d8d39da1545dde07a45384c28dfba5', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('b0c6b7a898037572a26555d254534b71', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('8c65f9618f3696e50c1a4c84e78f5687', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('165a381d1217467bbc586c121b9b183e', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('c448e4abf1bcf0d35d67a41b4cd79c04', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('cb5197e79bf6f7dedee1e2c1bfab5dc7', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('06f5f686924b0e240073428956d1f0fc', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('d56828406b70579ae33cb79be69d6c9b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('df037867533bcf9c26f394bdd5d5782d', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('592ff4e6a60e1a94b8aedf3415c61179', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('34664af68291f8c9ed458715692a3d3a', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('c317218ce68b7a19277ccdeaaffe8667', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('e06591c8185e6d1d43b8cd1db3c470c0', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('1692c274ae1bbc765c043ff00042aac7', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('f5709575505dea2dcbb8222274efd09b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('13e56a155ed4a3c3f386a068464fd3c8', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('a9f52b4004a5ff2e9fb2a819a4e6f9f5', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('7232d936a7c7988cbe811b6309182afa', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('97bb427555717113fbf52566da4870ca', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('84896153b38087b2428756040bad539b', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('d36caac76325e9246f479b152db2df93', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('cf8a2e61aa55c440e3138ca084873d07', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('5d314b14044810851904a539339aff52', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('74d5bfcff6f2254c0b0cc3d3f36ca49f', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('96c21a1d48ae5204b03ef52379e7ea10', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('2cab4d4c9b64d7f744a20a69983c2e00', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('19c9221fb80f1a9eba9d9ff46c0e3189', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('f502920bb2495078a92d662a51db4690', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);
INSERT INTO `tb_order` VALUES ('09e4d6932ace062ba32341825b9210cd', 'admin', '43486796d2871dfbec0f62951750ea4c', '100', null, null, null, null);

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `user_name` varchar(20) DEFAULT '' COMMENT '用户名',
  `password` varchar(256) DEFAULT '' COMMENT '密码',
  `user_type` smallint(6) DEFAULT '0' COMMENT '用户类型：1位管理员，0为普通',
  `name` varchar(30) DEFAULT NULL COMMENT '学生姓名',
  `sex` int(5) DEFAULT NULL COMMENT '女：0， 男：1',
  `remark` varchar(2000) DEFAULT NULL COMMENT '备忘',
  `creater` varchar(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `updater` varchar(20) DEFAULT '' COMMENT '编辑人',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('0272a998f8982854079e6ca6a2414f3a', 'admin', '$2a$10$D75MUfl24psN1u82/C8PZuLX2m6Aj7K7OuOZ4V6eX4nnewHX1dUsq', '0', null, null, null, null, '2020-06-11 00:08:20', null, '2020-06-11 00:08:20');
INSERT INTO `tb_user` VALUES ('1', '1', '1', '0', '1', '1', '1', '1', '2020-06-04 22:43:07', '1', '2020-06-09 22:43:11');
INSERT INTO `tb_user` VALUES ('2', '2', '1', '0', '1', '0', '1', '1', '2020-06-09 22:43:31', '1', '2020-06-25 22:43:40');
INSERT INTO `tb_user` VALUES ('6c01fbeba1bd37389fc3c8a9fa23c0f6', 'ceshi1', '$2a$10$a0iCJUaAiTBYMsFmnyXnXOgXU4aE/ALCqj7DUWfdc0VxSP9a2jaUe', '0', null, null, null, 'admin', '2020-06-11 02:05:51', 'admin', '2020-06-11 02:05:51');
INSERT INTO `tb_user` VALUES ('6f06886564bbfc8c5752129ba5f406dc', 'ceshi', '$2a$10$MYRLYFDdLxSzPqvgCBYe4OlCnzHVbwzUxG5cFj4kjQm/UBL0TEEAq', '0', null, null, null, 'admin', '2020-06-11 02:03:38', 'admin', '2020-06-11 02:03:38');
