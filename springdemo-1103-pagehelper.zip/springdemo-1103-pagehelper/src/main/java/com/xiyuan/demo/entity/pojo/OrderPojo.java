package com.xiyuan.demo.entity.pojo;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;


/**
 * 订单模块
 */
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class OrderPojo extends CommodityPojo {

    private static final long serialVersionUID = -6588047039350568107L;

    private String id;//订单编号

    private String userId;//用户编号

    private String productId;//商品编号

    private Long orderPrice;//订单价格

    private String tempId; //用于存放一次请求的结果的id

}