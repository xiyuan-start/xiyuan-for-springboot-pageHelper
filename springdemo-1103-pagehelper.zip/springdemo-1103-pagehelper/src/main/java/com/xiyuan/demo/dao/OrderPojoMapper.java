package com.xiyuan.demo.dao;

import com.xiyuan.demo.entity.pojo.OrderPojo;
import org.springframework.stereotype.Component;
/**
 * 这是订单dao
 */
@Component
public interface OrderPojoMapper  {

    int insert(OrderPojo record);

    int insertSelective(OrderPojo record);
}