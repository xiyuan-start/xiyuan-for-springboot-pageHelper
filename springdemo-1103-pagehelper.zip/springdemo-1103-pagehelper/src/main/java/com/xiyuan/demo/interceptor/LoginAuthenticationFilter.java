package com.xiyuan.demo.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.service.impl.UserService;
import com.xiyuan.demo.utils.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * 以拦截的方式进行请求访问管理
 */
public class LoginAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    UserService userService;

    @Autowired
    JwtTokenUtil jwtTokenUtil;


    public static LoginAuthenticationFilter loginAuthenticationFilter;

    // 关键3
    @PostConstruct
    public void init() {
        loginAuthenticationFilter = this;
        loginAuthenticationFilter.userService = this.userService;
    }

    public LoginAuthenticationFilter() {
        AntPathRequestMatcher requestMatcher = new AntPathRequestMatcher("/demo/userinfo/loginUser", "POST");
        this.setRequiresAuthenticationRequestMatcher(requestMatcher);
        this.setAuthenticationManager(getAuthenticationManager());
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if (!request.getMethod().equals("POST")) {//必须post登录
            throw new AuthenticationServiceException(
                    "Authentication method not supported: " + request.getMethod());
        }
        String token = null;
        String username = null;
        String password = null;
        String vercode = null;
        //以json形式处理数据
        try {
            //将请求中的数据转为map
            Map<String, String> map = new ObjectMapper().readValue(request.getInputStream(), Map.class);
            username = map.get("userName");
            password = map.get("password");
            vercode = map.get("vercode");
            token = map.get("token");
            request.getSession().setAttribute("vercode", vercode);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (token == null) {//使用密码进行登录
            //如果是application/json类型，做如下处理
            if (request.getContentType() != null && (request.getContentType().equals(MediaType.APPLICATION_JSON_UTF8_VALUE) || request.getContentType().equals(MediaType.APPLICATION_JSON_VALUE))) {

                if (username == null) {
                    username = "";
                }
                if (password == null) {
                    password = "";
                }
                username = username.trim();
                UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
                setDetails(request, authRequest);
                return this.getAuthenticationManager().authenticate(authRequest);
            }
        } else {//使用用户令牌进行登录
            String usernameTemp = jwtTokenUtil.getUserNameFromToken(token);
            request.getSession().setAttribute("token", 1);
            UserInfoPojo userInfoPojo = userService.loginbyUsername(usernameTemp);
            UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(usernameTemp, userInfoPojo.getPassword());
            setDetails(request, authRequest);
            return this.getAuthenticationManager().authenticate(authRequest);
        }

        //否则使用官方默认处理方式
        return super.attemptAuthentication(request, response);
    }
}
