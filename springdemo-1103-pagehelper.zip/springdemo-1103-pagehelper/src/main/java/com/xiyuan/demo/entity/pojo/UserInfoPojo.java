package com.xiyuan.demo.entity.pojo;


import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xiyuan.demo.entity.CommentPojo;
import com.xiyuan.demo.utils.RedisDistUtil;
import lombok.*;

/**
 * 用户Pojo
 */
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class UserInfoPojo extends CommentPojo {

    private static final long serialVersionUID = -272044773727744948L;

    private String id; //主键

    @ExcelProperty(value = "用户名（必填）", index = 0)
    private String userName; //用户名

    @ExcelProperty(value = "密码（必填）", index = 1)
    private String password;//密码

    @ExcelProperty(value = "用户类型", index = 4)
    private Short userType;//用户类型 1为管理员 0位普通用户

    private String userTypeStr;

    @ExcelProperty(value = "备忘", index = 6)
    private String remark;//备忘

    @ExcelProperty(value = "姓名（必填）", index = 2)
    private String name;//姓名

    private Integer sex;//性别

    @ExcelProperty(value = "性别（必填）", index = 5)
    private String sexStr; //用于展示性别

    private String vercode; //验证码

    /**
     * 数据字典值替换
     **/
    public String getSexStr() {
        return this.sex != null ? RedisDistUtil.transformStr("sex", this.sex) : "";
    }

    public String getUserTypeStr() {
        return this.userType != null ? RedisDistUtil.transformStr("userType", this.userType) : "";
    }
}