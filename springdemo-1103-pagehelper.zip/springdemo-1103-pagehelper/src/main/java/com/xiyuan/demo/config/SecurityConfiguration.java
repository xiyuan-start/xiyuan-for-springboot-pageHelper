package com.xiyuan.demo.config;

import com.xiyuan.demo.entity.responsestatus.*;
import com.xiyuan.demo.interceptor.LoginAuthenticationFilter;
import com.xiyuan.demo.interceptor.MyAuthenticationProvider;
import com.xiyuan.demo.service.comment.AuthUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;

/**
 * SpringSecurity配置类
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)  //  启用方法级别的权限认证
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {


    @Autowired
    MyAuthenctiationEntryPointHandler myAuthenctiationEntryPointHandler;//未登录
    @Autowired
    MyAuthenctiationSuccessHandler myAuthenctiationSuccessHandler;//登陆成功
    @Autowired
    MyAuthenctiationFailureHandler myAuthenctiationFailureHandler;//登录失败
    @Autowired
    MyAuthenctiationDeniedHandler myAuthenctiationDeniedHandler;//无权访问
    @Autowired
    MyAuthenctiationLogoutSuccessHandler myAuthenctiationLogoutSuccessHandler;//退出成功
    @Autowired
    MyAuthenctiationInvalidSessionStrategy mMyAuthenctiationInvalidSessionStrategy;//session到期
    @Autowired
    MyAuthenctiationSessionInformationExpiredStrategy myAuthenctiationSessionStrategy;//session到期,被登陆


    //注入封装账号信息的处理bean
    @Bean
    UserDetailsService detailsService() {
        return new AuthUserDetailsService();
    }

    /*配置用户登录拦截器，解决username无法获取的问题*/
    @Bean
    LoginAuthenticationFilter loginAuthenticationFilter() throws Exception {
        LoginAuthenticationFilter filter = new LoginAuthenticationFilter();
        filter.setAuthenticationManager(authenticationManagerBean());
        filter.setAuthenticationSuccessHandler(myAuthenctiationSuccessHandler);//登录成功
        filter.setAuthenticationFailureHandler(myAuthenctiationFailureHandler);//登录失败
        return filter;
    }



    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/**");
        // web.ignoring().antMatchers("/demo/userinfo/loginValidateCode","/swagger-ui.html","/swagger-resources/configuration/security",
        // "/swagger-resources/configuration/ui","/swagger*//**","/api/v1/login","/v2/api-docs",
        // "/configuration/ui", "/swagger-resources", "/configuration/security", "/swagger-ui.html", "/webjars/**");
    }

    //用户授权操作
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        System.out.println("Spring Security 被启用");
        http
                .addFilterAt(loginAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class)
                .authorizeRequests()
                .antMatchers("/demo/userinfo/**").hasRole("USER")
                .anyRequest().authenticated()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint(myAuthenctiationEntryPointHandler)//未登录402
                .accessDeniedHandler(myAuthenctiationDeniedHandler)//无权访问403
                .and()
                .formLogin().loginPage("/demo/userinfo/loginUser")
                .successHandler(myAuthenctiationSuccessHandler)//登陆成功200
                .failureHandler(myAuthenctiationFailureHandler)//登陆失败401
                .permitAll()
                .and()
                .sessionManagement()//session到期提示
                .invalidSessionStrategy(mMyAuthenctiationInvalidSessionStrategy)//session到期101
                .and()
                .requestCache().disable()
                .logout()
                .logoutSuccessHandler(myAuthenctiationLogoutSuccessHandler)//退出登陆200
                .and()
                .csrf().disable(); //关闭CSRF
    }

    //设置加密方式
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityContextRepository securityContextRepository() {
        //设置对spring security的UserDetails进行session保存,这个必须要有，不然不会保存至session对应的缓存redis中
        HttpSessionSecurityContextRepository httpSessionSecurityContextRepository =
                new HttpSessionSecurityContextRepository();
        return httpSessionSecurityContextRepository;
    }

    //加入中间验证层，可实现自定义验证用户等信息
    @Bean
    public AuthenticationProvider authenticationProvider() {
        AuthenticationProvider provider = new MyAuthenticationProvider();
        return provider;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authenticationProvider());
    }


}