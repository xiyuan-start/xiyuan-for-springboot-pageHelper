package com.xiyuan.demo.dao;


import com.xiyuan.demo.entity.pojo.SysDictPojo;
import org.springframework.stereotype.Component;

/**
 * 字典子项的dao
 */
@Component
public interface SysDictPojoMapper  {

    int deleteByPrimaryKey(String code);

    int insert(SysDictPojo record);

    int insertSelective(SysDictPojo record);

    SysDictPojo selectByPrimaryKey(String code);

    int updateByPrimaryKeySelective(SysDictPojo record);

    int updateByPrimaryKey(SysDictPojo record);
}