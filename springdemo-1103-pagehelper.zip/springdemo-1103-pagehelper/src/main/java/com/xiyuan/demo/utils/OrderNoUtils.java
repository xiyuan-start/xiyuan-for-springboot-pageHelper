package com.xiyuan.demo.utils;

public class OrderNoUtils {

    private OrderNoUtils() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * 生成订单号
     *
     * @param productNo
     *            手机号
     * @return
     */
    public static String createOrderNo(String productNo) {
        return DateTimeUtils.getTodayChar14() + productNo
                + RandomNumberUtil.createRandomNumber(6);
    }


    /**
     * 生成VIP权益包业务主键
     *
     * @param productNo
     *            手机号
     * @return
     */
    public static String createVipBizNo(String productNo) {
        return "VIP" + DateTimeUtils.getTodayChar14() + productNo
                + RandomNumberUtil.createRandomNumber(4);
    }

    /**
     * 生成流水号
     * @param identifier
     * @param randomLength
     * @return
     */
    public static String createRequestNo(String identifier,int randomLength) {
        return DateTimeUtils.getTodayChar17() + identifier
                + RandomNumberUtil.createRandomNumber(randomLength);
    }

    /**
     * 生成用户唯一标识码
     * @param identifier
     * @param randomLength
     * @return
     */
    public static String createUserNo(String identifier,int randomLength) {
        return "VIP"+DateTimeUtils.getTodayChar17() + identifier
                + RandomNumberUtil.createRandomNumber(randomLength);
    }
}
