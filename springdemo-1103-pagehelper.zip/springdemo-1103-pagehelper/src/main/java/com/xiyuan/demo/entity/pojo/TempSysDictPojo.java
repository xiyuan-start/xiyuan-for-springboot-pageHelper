package com.xiyuan.demo.entity.pojo;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 用户初始化数据字典
 */
@Setter
@Getter
@ToString
public class TempSysDictPojo implements Serializable {

    private static final long serialVersionUID = -5946615763172172920L;

    private String sysdictTypeValue;//码值类型

    private Integer sysdictValue;//码值

    private String sysdictName;//码值展示值

}
