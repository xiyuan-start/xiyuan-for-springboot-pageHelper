package com.xiyuan.demo.dao;



import com.xiyuan.demo.entity.pojo.CommodityPojo;
import org.springframework.stereotype.Component;

/**
 * 这是商品的dao
 */
@Component
public interface CommodityPojoMapper {

    int insert(CommodityPojo record);

    int insertSelective(CommodityPojo record);
}