package com.xiyuan.demo.entity.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xiyuan.demo.entity.CommentPojo;
import lombok.*;


/**
 * 商品模块
 */

@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class CommodityPojo extends CommentPojo {


    private static final long serialVersionUID = -8623499490812206167L;

    private String id;//主键

    private Integer commodityType;//商品类型

    private String commodityName;//商品名称

    private Long commodityPrice;//商品价格

    private Integer commodityAllNum;//商品总数

    private Integer commoditySoldNum;//商品已售数

    private String remark;//备忘

}