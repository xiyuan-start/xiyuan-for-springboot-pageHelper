package com.xiyuan.demo.entity.param;

import com.xiyuan.demo.annotation.PhoneFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 用于用户操作的请求类
 */
@ToString
@Setter
@Getter
public class UserInfoPojoRes implements Serializable {

    private static final long serialVersionUID = -3963378057075235998L;

    @ApiModelProperty( notes = "主键")
    private String id;

    @NotNull(message = "用户名为必填项，不得为空")
    @Size(min = 2,max = 20,message = "用户名长度要在2—8个字符")
    @ApiModelProperty( notes = "用户名")
    private String userName;

    @NotNull(message = "密码为必填项，不得为空")
    @Size(min = 10,max = 20,message = "用户名长度要在10—20个字符")
    @ApiModelProperty( notes = "密码")
    private String password;

    @ApiModelProperty( notes = "用户类型 1为管理员 0位普通用户")
    private Short userType;

    @ApiModelProperty( notes = "备忘")
    private String remark;

    @ApiModelProperty( notes = "姓名")
    private String name;

    @ApiModelProperty( notes = "性别 0为男 1为女")
    private Integer sex;

    //@PhoneFormat
    //private String phoneNumber;

}
