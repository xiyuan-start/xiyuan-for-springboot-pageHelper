package com.xiyuan.demo.utils;

import com.xiyuan.demo.service.ISysDictService;
import org.springframework.context.ApplicationContext;


/**
 * 用于实现码值转化的工具类
 */
public class RedisDistUtil {

    //用于加载SpringBean
    private static ApplicationContext context  = SpringUtil.getApplicationContext();
    /**
     * 转化码值
     * @param distname
     * @param value
     * @return
     * @throws Exception
     */
    public static String transformStr(String distname, int value)  {
        ISysDictService iSysDictService =context.getBean(ISysDictService.class);
        return iSysDictService.transformStr(distname,value);
    }
}
