package com.xiyuan.demo.entity.param;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 分页模糊查询请求的封装类
 */
@Setter
@Getter
@ToString
public abstract class PageRequestPam implements Serializable {
    private static final long serialVersionUID = 1L;
    private int pageNum; //页面序号
    private int pageSize;  //页面大小
}
