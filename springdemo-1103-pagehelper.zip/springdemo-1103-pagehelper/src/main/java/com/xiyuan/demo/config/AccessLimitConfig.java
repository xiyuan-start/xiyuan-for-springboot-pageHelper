package com.xiyuan.demo.config;

import com.xiyuan.demo.interceptor.AccessLimitInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 用于排除对swagger资源文件的拦截
 * SpringSecurity结合自定义注解实现权限管理
 */
@Configuration
public class AccessLimitConfig implements WebMvcConfigurer {

    //这里需要注入拦截器 否则无法获取到拦截器注入的RedisTemplate<String, Integer> redisTemplate;
    @Bean
    public AccessLimitInterceptor accessLimitInterceptor() {
        return new AccessLimitInterceptor();
    }

    /**
     * 配置拦截器
     *
     * @param registry
     * @author lance
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(accessLimitInterceptor()).addPathPatterns("/**").excludePathPatterns("/demo/userinfo/loginValidateCode", "/swagger-ui.html", "/swagger-resources/configuration/security",
                "/swagger-resources/configuration/ui", "/swagger*//**", "/api/v1/login", "/v2/api-docs",
                "/configuration/ui", "/swagger-resources", "/configuration/security", "/swagger-ui.html", "/webjars/**");
    }

}
