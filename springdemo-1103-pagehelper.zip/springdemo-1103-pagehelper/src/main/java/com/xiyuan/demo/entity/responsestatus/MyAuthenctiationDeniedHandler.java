package com.xiyuan.demo.entity.responsestatus;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;
import com.alibaba.fastjson.JSON;

/**
 * 无权访问
 */
@Component
@Slf4j
public class MyAuthenctiationDeniedHandler implements AccessDeniedHandler {

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
                       AccessDeniedException accessDeniedException) throws IOException, ServletException {
        log.info("无权访问！");
        response.getWriter().write(JSON.toJSONString(ResponseResult.error(CouponTypeEnum.NEED_AUTHORITIES)));
    }
}
