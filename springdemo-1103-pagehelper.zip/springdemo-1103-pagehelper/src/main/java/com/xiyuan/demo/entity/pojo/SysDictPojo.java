package com.xiyuan.demo.entity.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xiyuan.demo.entity.CommentPojo;
import lombok.*;

/**
 * 字典子项Pojo
 */
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class SysDictPojo extends CommentPojo {

    private static final long serialVersionUID = 2696293311193703233L;
    private String code; //主键

    private String typeCode;//码表对应的外键

    private String name;//展示值

    private Integer value;//真实值

    private Integer fixed;//是否固定 1固定 0不固定

}