package com.xiyuan.demo.utils;


import com.github.pagehelper.PageInfo;
import com.xiyuan.demo.entity.param.PageRequestPam;

public class PageUtils {
    /**
     * 将分页信息封装到统一的接口
     * @param pam
     * @param pageInfo
     * @return
     */
    public static Page getPageResult(PageRequestPam pam, PageInfo<?> pageInfo) {
        Page page = new Page();
        page.setPageNo(pageInfo.getPageNum());
        page.setPageSize(pageInfo.getPageSize());
        page.setTotalSize(pageInfo.getTotal());
        page.setTotalPages(pageInfo.getPages());
        page.setValue(pageInfo.getList());
        return page;
    }
}