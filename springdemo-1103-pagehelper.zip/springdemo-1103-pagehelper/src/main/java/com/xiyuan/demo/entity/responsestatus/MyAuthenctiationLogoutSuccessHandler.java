package com.xiyuan.demo.entity.responsestatus;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiyuan.demo.entity.ResponseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

/**
 * 退出登录
 *
 */
@Component
@Slf4j
public class MyAuthenctiationLogoutSuccessHandler implements LogoutSuccessHandler{

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
            throws IOException, ServletException {
        log.info("退出登录！");
        //删除用户令牌
        request.getSession().setAttribute("token","");
        response.getWriter().write(JSON.toJSONString(ResponseResult.success("退出登录")));
    }
}



