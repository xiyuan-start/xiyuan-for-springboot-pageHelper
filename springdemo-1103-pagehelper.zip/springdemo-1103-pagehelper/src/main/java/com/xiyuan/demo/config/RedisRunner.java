package com.xiyuan.demo.config;

import com.xiyuan.demo.dao.SysDictTypePojoMapper;
import com.xiyuan.demo.dao.UserInfoPojoMapper;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.pojo.TempSysDictPojo;
import com.xiyuan.demo.service.comment.RedisService;
import com.xiyuan.demo.utils.BloomFilterHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * 该类用于在启动项目时，加载数据字典，以及初始化布隆过滤器
 */
@Component
@Slf4j
@SuppressWarnings({ "unchecked"})
public class RedisRunner implements CommandLineRunner {

    @Autowired
    private RedisService redisService;

    @Autowired
    private UserInfoPojoMapper userInfoPojoMapper;

    @Autowired
    private BloomFilterHelper bloomFilterHelper;

    @Autowired
    SysDictTypePojoMapper sysDictTypePojoMapper;

    @Autowired
    RedisTemplate redisTemplate;

    //是否开启数据字典的开关
    @Value(value = "${sysdictswitch}")
    Boolean sysdictswitch;

    /**
     * 将username放在指定的布隆过滤器中
     *
     * @param args
     * @throws Exception
     */
    @Override

    public void run(String... args) throws Exception {
        if (sysdictswitch) {//开启初始化数据字典和布隆过滤器

        /**初始化用户名重复校验的布隆过滤器**/
        log.info("**** 开始初始化布隆表达式 ****");
        List<UserInfoPojo> wbUsers = userInfoPojoMapper.selectByPrimaryKeys(null);
        long startTime = System.currentTimeMillis();   //获取开始时间
        // 初始化布隆过滤器内容
        for (UserInfoPojo user : wbUsers) {
            redisService.addByBloomFilter(bloomFilterHelper, "bloom", user.getUserName());
        }
        long endTime = System.currentTimeMillis(); //获取结束时间
        log.info("插入布隆过滤器，总数据条数：" + wbUsers.size() + "用时：" + (endTime - startTime) + "ms");
        log.info("****结束初始化布隆表达式 ****");


        /**初始化数据字典**/
            log.info("**** 开始初始化数据字典 ****");
            List<TempSysDictPojo> list = sysDictTypePojoMapper.initializationSysDict();
            for (TempSysDictPojo tempSysDictPojo : list) {
                redisTemplate.opsForValue().set(tempSysDictPojo.getSysdictTypeValue() + "_" + tempSysDictPojo.getSysdictValue(), tempSysDictPojo.getSysdictName());
            }
            log.info("**** 结束初始化数据字典 ****");
        }
    }
}

