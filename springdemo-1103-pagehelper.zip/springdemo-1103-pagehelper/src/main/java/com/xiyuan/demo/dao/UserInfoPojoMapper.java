package com.xiyuan.demo.dao;

import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.param.UserInfoForSearchRes;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * 用户模块
 */
@Component
public interface UserInfoPojoMapper  {


    /**
     *用户登录
     * @param userName
     * @param tempPassword
     * @return
     */
    UserInfoPojo login(@Param("userName") String userName, @Param("tempPassword") String tempPassword);

    /**
     * 根据用户名获取用户
     * @param userName
     * @return
     */
    UserInfoPojo loginbyUsername(@Param("userName") String userName);

    /**
     * 分页查询获取总数据个数
     * @param
     * @return
     */
    int getUserInfoByPageCount(UserInfoForSearchRes userInfoForSearchRes);

    /**
     * 分页查询获取List
     * @param
     * @param
     * @param
     * @return
     */
    List<UserInfoPojo> getUserInfoByPage(UserInfoForSearchRes userInfoForSearchRes);

    /**
     * 获取用户信息（不分页）
     * @param userInfoForSearchRes
     * @return
     */
    List<UserInfoPojo> getUserInfoByPageNoPage(UserInfoForSearchRes userInfoForSearchRes);

    /**
     * 批量插入
     * @param collect
     */
    void BatchInsert(List<UserInfoPojo> collect);


    int deleteByPrimaryKey(String id);

    int insert(UserInfoPojo record);

    int insertSelective(UserInfoPojo record);

    UserInfoPojo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(UserInfoPojo record);

    int updateByPrimaryKey(UserInfoPojo record);

    List<UserInfoPojo> selectByPrimaryKeys(List<String> listId);
}