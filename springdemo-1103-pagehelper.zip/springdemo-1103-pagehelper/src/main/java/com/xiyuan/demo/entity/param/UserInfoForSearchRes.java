package com.xiyuan.demo.entity.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;


/**
 * 这是用户查询的封装类
 */
@Setter
@Getter
@ToString
@ApiModel("用户查询请求类")
public class UserInfoForSearchRes extends PageRequestPam {
    private static final long serialVersionUID = -5625703056478578435L;

    @ApiModelProperty( notes = "用户名", example = "xiyuan666")
    private String userName;

    @ApiModelProperty( notes = "查询开始时间")
    private Date searchStartTime;

    @ApiModelProperty( notes = "查询结束时间")
    private Date searchEndTime;

}
