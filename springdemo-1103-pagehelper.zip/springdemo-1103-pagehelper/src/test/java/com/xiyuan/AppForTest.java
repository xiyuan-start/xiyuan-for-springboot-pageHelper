package com.xiyuan;

import com.xiyuan.demo.App;
import org.junit.Test;
import org.junit.runner.RunWith;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
//启动Spring
@SpringBootTest(classes = App.class)
public class AppForTest {

   @Value("${batchInsertCount:10}")
   Integer batchInsertCount;

   @Test
    public void ceshi(){
       System.out.println(batchInsertCount);
   }

}
