package com.xiyuan.executor;


import org.junit.Test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class My001Test {

    @Test
    public void test001(){

        Vector vector =new Vector();


        //数组转化成list
        String array[] ={"a","b"};
        List <String>list = Arrays.asList(array);

        //list转化成Array
        String arratb[] =(String [])list.toArray();


    }
}
