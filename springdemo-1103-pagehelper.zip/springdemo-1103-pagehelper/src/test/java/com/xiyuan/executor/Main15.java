package com.xiyuan.executor;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Main15 {

    public static ExecutorService mythread = Executors.newFixedThreadPool(1024);
    public static void main(String[] args) {
        for (int i=0;i<10;i++){
            mythread.execute(new Runnable() {
                public void run() {
                    System.out.println("执行");
                }
            });
        }
    }
}