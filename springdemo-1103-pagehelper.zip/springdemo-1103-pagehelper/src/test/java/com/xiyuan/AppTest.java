package com.xiyuan;


import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import com.xiyuan.demo.service.impl.CommodityService;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Unit test for simple App.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class AppTest 
{
    private static int size = 1000000;//预计要插入多少数据

    private static double fpp = 0.01;//期望的误判率

    private static BloomFilter<Integer> bloomFilter = BloomFilter.create(Funnels.integerFunnel(), size, fpp);

    @Resource
    CommodityService commodityService;

    public CommodityService getDicService() {
           return commodityService;
        }

            public void setDicService(CommodityService commodityService) {
             this.commodityService = commodityService;
        }


}
